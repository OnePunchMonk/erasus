"""
erasus.metrics.efficiency — Efficiency metrics.
"""
