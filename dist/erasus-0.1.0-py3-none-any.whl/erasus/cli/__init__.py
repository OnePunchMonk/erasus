"""erasus.cli — Command-line interface."""
