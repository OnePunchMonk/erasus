"""
erasus.metrics.forgetting — Forgetting quality metrics.
"""
