"""erasus.models — Model wrapper package."""

from erasus.models.model_wrapper import BaseModelWrapper

__all__ = ["BaseModelWrapper"]
